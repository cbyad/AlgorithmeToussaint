package com.cpa.algorithms;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.ArrayList;


import javafx.scene.shape.Line;

public class Toussaint {

	public static Point2D.Double[] rectangle= new Point2D.Double[4];


	public static  ArrayList<Line>  toussaint (ArrayList<Point> points ){

		ArrayList<Point> enlevoppe = Convex.enveloppeConvexe(points);

		//ArrayList<Line> line = Convex.calculPairesAntipodales(enlevoppe);

		return Convex.calculPairesAntipodales(enlevoppe);

	}


	public static	ArrayList<Line>  getRectangleMin (ArrayList<Line> pointsAntiPodal, ArrayList<Point> enveloppe){

		Double rectangleMinArea = Double.MAX_VALUE;

		ArrayList<Line> result = new ArrayList<>();

		for (Point p : enveloppe)
			System.out.println(p);

		for (Point p : getPointsFromLine(pointsAntiPodal)) {

			Point p1Suiv = enveloppe.get((enveloppe.indexOf(p) + 1 )%enveloppe.size());

			double a = (1.0*(p1Suiv.y-p.y))/(p1Suiv.x-p.x);
			double b = p.y- (a*p.x);


			double newB, bestB = Integer.MAX_VALUE;
			Point bestP = new Point();
			ArrayList<Point> pairesCommunes = pointsAntiPodalCommun(p, pointsAntiPodal);
			for (Point pAntiPod : pairesCommunes) {
				newB = pAntiPod.y - (a * pAntiPod.x);
				if (newB > b) {
					if (bestB == Integer.MAX_VALUE || newB > bestB) {
						bestB = newB;
						bestP = pAntiPod;
					}
				} else {
					if (bestB > newB) {
						bestB = newB;
						bestP = pAntiPod;
					}
				}
			}
			double BGauche = Double.MAX_VALUE, Bdroite = Double.MIN_VALUE;
			Point pGauche = new Point();
			Point pDroit = new Point();
			double Btemp;

			for(Point pt: enveloppe ){
				Btemp = pt.y - ( (-1 / a) * pt.x );

				if (Btemp> Bdroite)	{
					Bdroite= Btemp ;
					pDroit=pt ;
				}		

				if(Btemp<BGauche){
					BGauche=Btemp;
					pGauche=pt;
				}	
			}

			Line deltaAB , deltaCD ,deltaBD ,deltaAC ;

			//    		(deltaAB // deltaCD)
			deltaAB = new Line(p.x,p.y,100,a*100+b) ;
			deltaCD = new Line(bestP.x,bestP.y,100,a*100+bestB);

			//		    (deltaBD // deltaAC)
			deltaBD=new Line(pGauche.x,pGauche.y,100,(-1/a)*100+BGauche);
			deltaAC=new Line(pDroit.x,pDroit.y,100,(-1/a)*100+Bdroite);


			result.add(deltaAB);
			result.add(deltaCD);

			result.add(deltaBD);
			result.add(deltaAC);

			//calcul des 4 points d'intersections 

			double xA = (getOrderedO(deltaAC)-getOrderedO(deltaAB)) / (getCoefficientDirect(deltaAB)-getCoefficientDirect(deltaAC)) ;

			double yA= getCoefficientDirect(deltaAC)*xA + getOrderedO(deltaAC);

			Point2D.Double A = new Point2D.Double(xA, yA);


			double xB = (getOrderedO(deltaBD)-getOrderedO(deltaAB)) / (getCoefficientDirect(deltaAB)-getCoefficientDirect(deltaBD)) ;

			double yB= getCoefficientDirect(deltaBD)*xB + getOrderedO(deltaBD);

			Point2D.Double B = new Point2D.Double(xB, yB);


			double xC = (getOrderedO(deltaAC)-getOrderedO(deltaCD)) / (getCoefficientDirect(deltaCD)-getCoefficientDirect(deltaAC)) ;

			double yC= getCoefficientDirect(deltaAC)*xC + getOrderedO(deltaAC);

			Point2D.Double C = new Point2D.Double(xC, yC);


			double xD = (getOrderedO(deltaBD)-getOrderedO(deltaCD)) / (getCoefficientDirect(deltaCD)-getCoefficientDirect(deltaBD)) ;

			double yD= getCoefficientDirect(deltaBD)*xD + getOrderedO(deltaBD);

			Point2D.Double D = new Point2D.Double(xD, yD);

			rectangle[0] = A;
			rectangle[1] = B;
			rectangle[2] = D;
			rectangle[3] = C;

			if(Utils.rectangleArea(rectangle)<rectangleMinArea){
				rectangleMinArea= Utils.rectangleArea(rectangle) ;

			}


			//return result;
		}

		return result ;

	}

	public static ArrayList<Point> pointsAntiPodalCommun(Point p1 , ArrayList<Line> antipodales){
		ArrayList<Point> listePoints =  new ArrayList<>();
		ArrayList<Point> pairePodale = getPointsFromLine(antipodales);

		for (int i = 0 ; i < pairePodale.size() ; i += 2) { // l (x1,x2,y1,y2)

			if(p1.equals(pairePodale.get(i))){
				listePoints.add(pairePodale.get(i + 1));
			}
			else if (p1.equals(pairePodale.get(i + 1))){
				listePoints.add(pairePodale.get(i));
			}
		}

		return listePoints ;
	}

	/**
	 * 
	 * @param line
	 * @return renvoie la liste de points contenue dans une liste de line(AB)
	 */
	public static ArrayList<Point> getPointsFromLine(ArrayList<Line> line ){
		ArrayList<Point> listePoints =  new ArrayList<>();

		for (Line l : line) {
			double x1 = l.getStartX();
			double y1= l.getStartY();
			double x2 = l.getEndX();
			double y2= l.getEndY();

			listePoints.add(new Point((int)x1,(int) y1) );
			listePoints.add(new Point((int)x2,(int)y2) );
		}
		return listePoints ;

	}

	/**
	 * 
	 * @param l
	 * @return le coefficient directeur d'une droite
	 */
	public static  double getCoefficientDirect(Line l){

		return (1.0*(l.getStartY()-l.getEndY()))/(l.getStartX()-l.getEndX());
	}

	/**
	 * 
	 * @param l
	 * @return l'ordonnee a l'origine d'une droite
	 */
	public  static double getOrderedO(Line l){

		return   l.getStartY()- (getCoefficientDirect(l)*l.getStartX());
	}

}