pour utiliser le projet
avoir javafx installer pour visualiser le graphique

- executer la cible ant compile pour compiler le projet
- ant view pour lancer la classe GraphicView

- pour lancer le benchmark faire java -jar cpa_toussaint_bench.jar "fileOutput.csv"
 
